package model;

/**
 * Interface that will generate a flag.
 */
public interface IFlag {
  int[][][] identifyFlag();
}
