import static org.junit.Assert.*;

/**
 * No test cases were required for our assignment as all outputs were visially representated by,
 * images present in the res folder.
 */
public class ImageDataTest {

}